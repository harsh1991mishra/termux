### STEPS FOR METASPLOIT
1. download the script in HOME directory `wget https://raw.githubusercontent.com/Hax4us/Metasploit_termux/master/metasploit.sh`
2. run `chmod +x metasploit.sh && ./metasploit.sh`

